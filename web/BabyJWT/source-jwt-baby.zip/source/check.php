<html>
<body>
 
<form action="auth.php" method="get">
Token: <input type="text" name="token"><br>
<input type="submit">
</form>
 
</body>
</html>
