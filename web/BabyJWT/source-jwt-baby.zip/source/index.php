<html>
<body>
 
<form action="auth.php" method="get">
Name: <input type="text" name="name"><br>
<input type="submit">
</form>
 <br/>
 <a href="/check.php">Check JWT token</a>
</body>
</html>
