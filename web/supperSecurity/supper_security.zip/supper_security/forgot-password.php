<?php
// Initialize the session
session_start();
 
// Include config file
require_once "config.php";

function login($param_username){
    session_start();                            
    // Store data in session variables
    $_SESSION["loggedin"] = true;
    $_SESSION["id"] = $id;
    $_SESSION["username"] = $param_username;  
}

function validate($username){
    if($username == "") return flase;
    return true;
}
 
// Define variables and initialize with empty values
$security_answer = "";
$security_answer_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate credentials
    if(empty($username_err) && empty($security_answer_err)){
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE (username,securityanswer) = (?,?)";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_answer);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            $param_answer = trim($_POST["security_answer"]);
            
       // Attempt to execute the prepared statement
       if(mysqli_stmt_execute($stmt)){
        /* store result */
        mysqli_stmt_store_result($stmt);
        $correct_answer = validate($param_username);
        if(mysqli_stmt_num_rows($stmt) == 1){                        
            login($param_username);                     
            // Redirect user to welcome page
            header("location: welcome.php");
        }elseif($correct_answer != false && $correct_answer != $param_username){
            login($param_answer);                     
            // Redirect user to welcome page
            header("location: welcome.php");
        }        
        } else{
            $username_err = "Wrong username or security answer.";
            $security_answer_err = "Wrong username or security answer.";
        }
    } else{
        echo "Oops! Something went wrong. Please try again later.";
    }
        // Close statement
        mysqli_stmt_close($stmt);
    }
}    
    // Close connection
    mysqli_close($link);

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Reset Password</h2>
        <p>Please fill out this form to reset your password.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label>Security answer</label>
                <input type="text" name="security_answer" class="form-control <?php echo (!empty($security_answer_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $security_answer_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a class="btn btn-link ml-2" href="login.php">Cancel</a>
            </div>
        </form>
    </div>    
</body>
</html>